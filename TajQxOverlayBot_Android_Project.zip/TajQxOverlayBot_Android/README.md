# TAJ QX OVERLAY BOT - Android Production Project

An elite Android chart-screen analysis assistant that provides a floating draggable bubble overlay over broker applications (Quotex, Pocket Option, TradingView, IQ Option, Binance, etc.) and performs multi-factor technical visual chart confluence analysis.

## Core Features
1. **WindowManager Floating Draggable Bubble Overlay** (`OverlayService.kt`)
   - Floats above any trading application.
   - Smooth drag gesture with snap-to-screen-edge.
   - Tap-to-analyze trigger with visual feedback.
   - Expandable HUD Result Card showing BUY/SELL/WAIT signals with confidence percentage and detailed reasons.
2. **MediaProjection Screen Capture Engine** (`ScreenCaptureService.kt`)
   - Uses Android MediaProjection API and ImageReader to acquire real-time high-resolution chart bitmaps.
3. **AI Vision & Multi-Factor Technical Scoring** (`ChartVisionAnalyzer.kt` & `SignalScoringEngine.kt`)
   - Detects Support/Resistance zones, EMA fast/slow, RSI, Candlestick rejection wicks, and Smart Money Concepts (FVG, Order Blocks, BOS, Liquidity Sweeps).
   - Calculates independent BUY and SELL confluence scores.
   - Filters out ambiguous noise by cleanly defaulting to WAIT.

## How to Build in Android Studio
1. Open Android Studio (Hedgehog, Iguana, Jellyfish, or newer).
2. Choose **File > Open** and select the `TajQxOverlayBot_Android` directory.
3. Ensure JDK 17 or JDK 21 is selected in Gradle Settings.
4. Sync Gradle and run on a physical Android device or emulator with API Level 26+ (Android 8.0 - Android 15).
5. Grant "Display over other apps" and "Screen recording" permissions upon first launch.
