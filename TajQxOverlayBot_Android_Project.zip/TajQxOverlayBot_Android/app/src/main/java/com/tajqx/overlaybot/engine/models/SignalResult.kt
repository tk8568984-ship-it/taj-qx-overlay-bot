package com.tajqx.overlaybot.engine.models

enum class SignalType {
    BUY,
    SELL,
    WAIT
}

data class ConfluenceCheck(
    val name: String,
    val passed: Boolean,
    val direction: SignalType,
    val impact: String,
    val scoreContribution: Int
)

data class SmartMoneyConcepts(
    val orderBlock: String,
    val fairValueGap: String,
    val marketStructureBreak: String,
    val liquiditySweep: String
)

data class TechnicalFactors(
    val trendDirection: String,
    val supportZone: String,
    val resistanceZone: String,
    val currentZoneReaction: String,
    val emaFastSlow: String,
    val candlestickPattern: String,
    val volatility: String,
    val smartMoney: SmartMoneyConcepts,
    val buyConfluenceScore: Int,
    val sellConfluenceScore: Int,
    val confluenceChecks: List<ConfluenceCheck>
)

data class SignalResult(
    val id: String,
    val timestamp: Long,
    val pair: String,
    val timeframe: String,
    val timing: String,
    val signal: SignalType,
    val confidence: Int,
    val reason: String,
    val technicalFactors: TechnicalFactors
)
