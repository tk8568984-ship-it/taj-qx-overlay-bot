package com.tajqx.overlaybot.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ObsidianDark = Color(0xFF090B10)
val CardBackground = Color(0xFF131722)
val RoseGold = Color(0xFFEC4899)
val NeonCyan = Color(0xFF06B6D4)
val EmeraldGreen = Color(0xFF10B981)
val RubyRed = Color(0xFFEF4444)
val AmberYellow = Color(0xFFF59E0B)

private val DarkColorScheme = darkColorScheme(
    primary = RoseGold,
    secondary = NeonCyan,
    tertiary = EmeraldGreen,
    background = ObsidianDark,
    surface = CardBackground,
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun TajQxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
