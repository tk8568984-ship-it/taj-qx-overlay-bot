package com.tajqx.overlaybot

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.tajqx.overlaybot.engine.TextToSpeechEngine

class TajQxApp : Application() {

    companion object {
        const val CHANNEL_ID_SCREEN_CAPTURE = "taj_qx_screen_capture"
        const val CHANNEL_ID_SIGNALS = "taj_qx_signals"
        lateinit var instance: TajQxApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
        TextToSpeechEngine.init(this)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val captureChannel = NotificationChannel(
                CHANNEL_ID_SCREEN_CAPTURE,
                "TAJ QX Chart Capture Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Runs background screen capture for live chart analysis"
            }

            val signalChannel = NotificationChannel(
                CHANNEL_ID_SIGNALS,
                "TAJ QX Trading Signals",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for BUY, SELL and WAIT trading signals"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(captureChannel)
            notificationManager.createNotificationChannel(signalChannel)
        }
    }
}
