package com.tajqx.overlaybot.engine

import com.tajqx.overlaybot.engine.models.ConfluenceCheck
import com.tajqx.overlaybot.engine.models.SignalResult
import com.tajqx.overlaybot.engine.models.SignalType
import com.tajqx.overlaybot.engine.models.TechnicalFactors

object SignalScoringEngine {

    private const val MINIMUM_CONFIDENCE_THRESHOLD = 65
    private const val MINIMUM_SCORE_MARGIN = 20

    /**
     * Evaluates independent BUY and SELL confluence factors to determine final signal.
     * Prevents false signals by defaulting strictly to WAIT if evidence is contradictory or insufficient.
     */
    fun evaluateConfluence(
        factors: TechnicalFactors,
        pair: String,
        timeframe: String,
        timing: String
    ): SignalResult {
        var buyScore = 0
        var sellScore = 0
        val checks = mutableListOf<ConfluenceCheck>()

        // 1. Trend Direction Alignment
        when {
            factors.trendDirection.contains("Bullish", ignoreCase = true) -> {
                buyScore += 25
                checks.add(ConfluenceCheck("Trend Direction", true, SignalType.BUY, "Higher highs & higher lows structure", 25))
            }
            factors.trendDirection.contains("Bearish", ignoreCase = true) -> {
                sellScore += 25
                checks.add(ConfluenceCheck("Trend Direction", true, SignalType.SELL, "Lower highs & lower lows structure", 25))
            }
            else -> {
                checks.add(ConfluenceCheck("Trend Direction", false, SignalType.WAIT, "Market is consolidating / sideways", 0))
            }
        }

        // 2. Support & Resistance Reaction
        if (factors.currentZoneReaction.contains("Support Bounce", ignoreCase = true) ||
            factors.currentZoneReaction.contains("Support Rejection", ignoreCase = true)) {
            buyScore += 20
            checks.add(ConfluenceCheck("S/R Reaction", true, SignalType.BUY, "Price rejecting major Support Zone", 20))
        } else if (factors.currentZoneReaction.contains("Resistance Rejection", ignoreCase = true) ||
                   factors.currentZoneReaction.contains("Resistance Bounce", ignoreCase = true)) {
            sellScore += 20
            checks.add(ConfluenceCheck("S/R Reaction", true, SignalType.SELL, "Price rejecting major Resistance Zone", 20))
        }

        // 3. EMA Fast / Slow Cross
        if (factors.emaFastSlow.contains("Golden Cross", ignoreCase = true) ||
            factors.emaFastSlow.contains("above", ignoreCase = true)) {
            buyScore += 15
            checks.add(ConfluenceCheck("EMA Alignment", true, SignalType.BUY, "Fast EMA above Slow EMA", 15))
        } else if (factors.emaFastSlow.contains("Death Cross", ignoreCase = true) ||
                   factors.emaFastSlow.contains("below", ignoreCase = true)) {
            sellScore += 15
            checks.add(ConfluenceCheck("EMA Alignment", true, SignalType.SELL, "Fast EMA below Slow EMA", 15))
        }

        // 4. Candlestick Price Action & Wicks
        if (factors.candlestickPattern.contains("Hammer", ignoreCase = true) ||
            factors.candlestickPattern.contains("Bullish Engulfing", ignoreCase = true) ||
            factors.candlestickPattern.contains("Lower Wick Rejection", ignoreCase = true)) {
            buyScore += 20
            checks.add(ConfluenceCheck("Candle Price Action", true, SignalType.BUY, factors.candlestickPattern, 20))
        } else if (factors.candlestickPattern.contains("Shooting Star", ignoreCase = true) ||
                   factors.candlestickPattern.contains("Bearish Engulfing", ignoreCase = true) ||
                   factors.candlestickPattern.contains("Upper Wick Rejection", ignoreCase = true)) {
            sellScore += 20
            checks.add(ConfluenceCheck("Candle Price Action", true, SignalType.SELL, factors.candlestickPattern, 20))
        }

        // 5. Smart Money Concepts (FVG / Liquidity Sweeps / Order Blocks)
        if (factors.smartMoney.liquiditySweep.contains("Sell-side Liquidity Swept", ignoreCase = true) ||
            factors.smartMoney.orderBlock.contains("Bullish OB", ignoreCase = true)) {
            buyScore += 20
            checks.add(ConfluenceCheck("Smart Money (SMC)", true, SignalType.BUY, "Sell-side sweep + Bullish Order Block tap", 20))
        } else if (factors.smartMoney.liquiditySweep.contains("Buy-side Liquidity Swept", ignoreCase = true) ||
                   factors.smartMoney.orderBlock.contains("Bearish OB", ignoreCase = true)) {
            sellScore += 20
            checks.add(ConfluenceCheck("Smart Money (SMC)", true, SignalType.SELL, "Buy-side sweep + Bearish Order Block tap", 20))
        }

        // Determine final verdict
        val finalSignal: SignalType
        val finalConfidence: Int
        val summaryReason: String

        if (buyScore >= MINIMUM_CONFIDENCE_THRESHOLD && (buyScore - sellScore) >= MINIMUM_SCORE_MARGIN) {
            finalSignal = SignalType.BUY
            finalConfidence = buyScore.coerceAtMost(92)
            summaryReason = "Strong Bullish Confluence: Price confirmed at ${factors.supportZone} with EMA alignment and candlestick rejection."
        } else if (sellScore >= MINIMUM_CONFIDENCE_THRESHOLD && (sellScore - buyScore) >= MINIMUM_SCORE_MARGIN) {
            finalSignal = SignalType.SELL
            finalConfidence = sellScore.coerceAtMost(92)
            summaryReason = "Strong Bearish Confluence: Price rejected at ${factors.resistanceZone} with downward momentum and liquidity sweep."
        } else {
            finalSignal = SignalType.WAIT
            finalConfidence = 50
            summaryReason = "Mixed signals detected (BUY Score: $buyScore%, SELL Score: $sellScore%). Market is in equilibrium or contradictory structure. Awaiting clear breakout."
        }

        return SignalResult(
            id = System.currentTimeMillis().toString(),
            timestamp = System.currentTimeMillis(),
            pair = pair,
            timeframe = timeframe,
            timing = timing,
            signal = finalSignal,
            confidence = finalConfidence,
            reason = summaryReason,
            technicalFactors = factors.copy(
                buyConfluenceScore = buyScore,
                sellConfluenceScore = sellScore,
                confluenceChecks = checks
            )
        )
    }
}
