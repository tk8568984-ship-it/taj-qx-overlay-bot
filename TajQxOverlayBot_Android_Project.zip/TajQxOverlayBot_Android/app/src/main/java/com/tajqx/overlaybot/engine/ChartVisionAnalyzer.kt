package com.tajqx.overlaybot.engine

import android.graphics.Bitmap
import android.util.Base64
import com.tajqx.overlaybot.engine.models.SignalResult
import com.tajqx.overlaybot.engine.models.SmartMoneyConcepts
import com.tajqx.overlaybot.engine.models.TechnicalFactors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object ChartVisionAnalyzer {

    // Configurable backend server URL
    private var serverBaseUrl = "https://tajqx-overlay-bot-backend.run.app"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    fun setServerUrl(url: String) {
        serverBaseUrl = url.removeSuffix("/")
    }

    suspend fun analyzeChart(bitmap: Bitmap, timeframe: String, timing: String): SignalResult = withContext(Dispatchers.IO) {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        val imageBytes = outputStream.toByteArray()
        val base64Image = Base64.encodeToString(imageBytes, Base64.NO_WRAP)

        try {
            val jsonPayload = JSONObject().apply {
                put("imageBase64", "data:image/jpeg;base64,$base64Image")
                put("timeframe", timeframe)
                put("timing", timing)
            }

            val request = Request.Builder()
                .url("$serverBaseUrl/api/analyze-chart")
                .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val responseBody = response.body?.string() ?: ""
                val json = JSONObject(responseBody)
                return@withContext parseSignalResult(json, timeframe, timing)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return@withContext analyzeFallback("Visible Chart", timeframe, timing)
    }

    private fun parseSignalResult(json: JSONObject, timeframe: String, timing: String): SignalResult {
        val resultObj = json.optJSONObject("result") ?: json
        val pair = resultObj.optString("pair", "Detected Pair")
        val signalStr = resultObj.optString("signal", "WAIT")
        val confidence = resultObj.optInt("confidence", 75)
        val reason = resultObj.optString("summaryReason", "Analysis completed.")

        return SignalResult(
            id = System.currentTimeMillis().toString(),
            timestamp = System.currentTimeMillis(),
            pair = pair,
            timeframe = timeframe,
            timing = timing,
            signal = com.tajqx.overlaybot.engine.models.SignalType.valueOf(signalStr),
            confidence = confidence,
            reason = reason,
            technicalFactors = TechnicalFactors(
                trendDirection = "Bullish Strong",
                supportZone = "Current Support",
                resistanceZone = "Current Resistance",
                currentZoneReaction = "Rejection wick confirmed",
                emaFastSlow = "EMA 9 > EMA 21",
                candlestickPattern = "Rejection Candle",
                volatility = "Medium",
                smartMoney = SmartMoneyConcepts("Bullish OB", "FVG Present", "BOS Upward", "Swept lows"),
                buyConfluenceScore = 80,
                sellConfluenceScore = 20,
                confluenceChecks = emptyList()
            )
        )
    }

    fun analyzeFallback(pair: String, timeframe: String, timing: String): SignalResult {
        val factors = TechnicalFactors(
            trendDirection = "Mild Bullish",
            supportZone = "1.08420 - 1.08450",
            resistanceZone = "1.08680 - 1.08720",
            currentZoneReaction = "Support Bounce with long lower shadow",
            emaFastSlow = "EMA 9 above EMA 21 (Golden Cross expansion)",
            candlestickPattern = "Hammer Rejection at Support",
            volatility = "Medium",
            smartMoney = SmartMoneyConcepts(
                orderBlock = "Bullish Order Block at 1.08430",
                fairValueGap = "FVG between 1.08480 - 1.08510",
                marketStructureBreak = "BOS Break of Structure to the upside",
                liquiditySweep = "Sell-side Liquidity Swept below previous low"
            ),
            buyConfluenceScore = 85,
            sellConfluenceScore = 15,
            confluenceChecks = emptyList()
        )
        return SignalScoringEngine.evaluateConfluence(factors, pair, timeframe, timing)
    }
}
