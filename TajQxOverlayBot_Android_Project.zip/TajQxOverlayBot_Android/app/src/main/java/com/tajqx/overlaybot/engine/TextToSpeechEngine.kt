package com.tajqx.overlaybot.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import com.tajqx.overlaybot.engine.models.SignalType
import java.util.Locale

object TextToSpeechEngine : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    fun init(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            tts?.setSpeechRate(1.05f)
            tts?.setPitch(1.0f)
            isInitialized = true
        }
    }

    fun speakSignal(signal: SignalType, confidence: Int) {
        if (!isInitialized || tts == null) return

        val textToSpeak = when (signal) {
            SignalType.BUY -> "BUY, $confidence percent"
            SignalType.SELL -> "SELL, $confidence percent"
            SignalType.WAIT -> "WAIT"
        }

        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, "taj_qx_signal_id")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
