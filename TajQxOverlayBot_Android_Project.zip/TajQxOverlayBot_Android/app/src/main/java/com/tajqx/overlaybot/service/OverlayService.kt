package com.tajqx.overlaybot.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Vibrator
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.tajqx.overlaybot.MainActivity
import com.tajqx.overlaybot.R
import com.tajqx.overlaybot.engine.ChartVisionAnalyzer
import com.tajqx.overlaybot.engine.TextToSpeechEngine
import com.tajqx.overlaybot.engine.models.SignalResult
import com.tajqx.overlaybot.engine.models.SignalType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        var isRunning = false
        var currentSignalListener: ((SignalResult) -> Unit)? = null
        var selectedTimeframe = "1m"
        var selectedTiming = "5s"
        var isVoiceEnabled = true
    }

    private lateinit var windowManager: WindowManager
    private var floatingBubbleView: View? = null
    private var hudResultCardView: View? = null

    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var hudParams: WindowManager.LayoutParams

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var isAnalyzing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupFloatingBubble()
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun setupFloatingBubble() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 300
        }

        floatingBubbleView = LayoutInflater.from(this).inflate(R.layout.layout_floating_bubble, null)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = false

        floatingBubbleView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isClick = false
                    }
                    bubbleParams.x = initialX + dx
                    bubbleParams.y = initialY + dy
                    windowManager.updateViewLayout(floatingBubbleView, bubbleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        triggerChartAnalysis()
                    } else {
                        snapToEdge()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(floatingBubbleView, bubbleParams)
    }

    private fun snapToEdge() {
        val screenWidth = resources.displayMetrics.widthPixels
        val middle = screenWidth / 2
        val targetX = if (bubbleParams.x + 100 < middle) 20 else screenWidth - 180
        bubbleParams.x = targetX
        windowManager.updateViewLayout(floatingBubbleView, bubbleParams)
    }

    private fun triggerChartAnalysis() {
        if (isAnalyzing) return
        isAnalyzing = true

        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        vibrator?.vibrate(50)

        floatingBubbleView?.findViewById<ProgressBar>(R.id.pb_bubble_loading)?.visibility = View.VISIBLE
        floatingBubbleView?.findViewById<ImageView>(R.id.iv_bubble_logo)?.alpha = 0.5f

        serviceScope.launch {
            try {
                val chartBitmap = ScreenCaptureService.captureCurrentFrame()
                val result = if (chartBitmap != null) {
                    ChartVisionAnalyzer.analyzeChart(chartBitmap, selectedTimeframe, selectedTiming)
                } else {
                    ChartVisionAnalyzer.analyzeFallback("Visible Chart", selectedTimeframe, selectedTiming)
                }

                showSignalResultHud(result)
                currentSignalListener?.invoke(result)

                if (isVoiceEnabled) {
                    TextToSpeechEngine.speakSignal(result.signal, result.confidence)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isAnalyzing = false
                floatingBubbleView?.findViewById<ProgressBar>(R.id.pb_bubble_loading)?.visibility = View.GONE
                floatingBubbleView?.findViewById<ImageView>(R.id.iv_bubble_logo)?.alpha = 1.0f
            }
        }
    }

    @SuppressLint("InflateParams")
    private fun showSignalResultHud(result: SignalResult) {
        if (hudResultCardView == null) {
            val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            hudParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = 120
            }

            hudResultCardView = LayoutInflater.from(this).inflate(R.layout.layout_signal_hud, null)
            windowManager.addView(hudResultCardView, hudParams)
        }

        val tvSignal = hudResultCardView?.findViewById<TextView>(R.id.tv_hud_signal)
        val tvConfidence = hudResultCardView?.findViewById<TextView>(R.id.tv_hud_confidence)
        val tvReason = hudResultCardView?.findViewById<TextView>(R.id.tv_hud_reason)
        val tvPair = hudResultCardView?.findViewById<TextView>(R.id.tv_hud_pair)
        val layoutCard = hudResultCardView?.findViewById<LinearLayout>(R.id.layout_hud_container)

        tvSignal?.text = result.signal.name
        tvConfidence?.text = "${result.confidence}% CONFIDENCE"
        tvReason?.text = result.reason
        tvPair?.text = "${result.pair} • ${result.timeframe} (${result.timing})"

        when (result.signal) {
            SignalType.BUY -> {
                tvSignal?.setTextColor(0xFF10B981.toInt())
                layoutCard?.setBackgroundResource(R.drawable.bg_hud_buy)
            }
            SignalType.SELL -> {
                tvSignal?.setTextColor(0xFFEF4444.toInt())
                layoutCard?.setBackgroundResource(R.drawable.bg_hud_sell)
            }
            SignalType.WAIT -> {
                tvSignal?.setTextColor(0xFFF59E0B.toInt())
                layoutCard?.setBackgroundResource(R.drawable.bg_hud_wait)
            }
        }

        hudResultCardView?.setOnClickListener {
            removeHudView()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            removeHudView()
        }, 8000)
    }

    private fun removeHudView() {
        hudResultCardView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // Ignore if already removed
            }
            hudResultCardView = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        floatingBubbleView?.let { windowManager.removeView(it) }
        removeHudView()
    }
}
